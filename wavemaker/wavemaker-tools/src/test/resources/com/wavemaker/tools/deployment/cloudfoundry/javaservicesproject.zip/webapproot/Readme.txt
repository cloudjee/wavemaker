  app.css contains application CSS
  config.js contains project settings that can be edited, including dojo settings. Generally for advanced users.
  index.html and login.html can be edited directly to customize, such as including meta, script and other tags. 
  types.js is a studio managed file. Types can be added to the project with server (java) types or with wm.TypeDefinition.
  project.documentation.js contains documentation for application owned components.
  project.js (i.e. myproject.js) contains any application owned component definitions and functions. Same as page js and widget.js for application owned components.
