dojo.declare("javaservicesproject", wm.Application, {
	"dialogAnimationTime": 350, 
	"disableDirtyEditorTracking": false, 
	"i18n": false, 
	"main": "Main", 
	"projectSubVersion": 2, 
	"projectVersion": 1, 
	"studioVersion": "6.4.1Beta", 
	"theme": "wm_default", 
	"toastPosition": "br",
	"widgets": {
		silkIconList: ["wm.ImageList", {"colCount":39,"height":16,"iconCount":90,"url":"lib/images/silkIcons/silk.png","width":16}, {}]
	},
	_end: 0
});

javaservicesproject.extend({

	_end: 0
});