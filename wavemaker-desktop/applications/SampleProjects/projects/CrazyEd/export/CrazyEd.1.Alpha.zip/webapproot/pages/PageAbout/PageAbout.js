dojo.declare("PageAbout", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	_end: 0
});