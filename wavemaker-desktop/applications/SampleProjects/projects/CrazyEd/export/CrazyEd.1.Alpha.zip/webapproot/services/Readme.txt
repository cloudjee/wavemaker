 Contains service definition files used by studio. These files are not user editable. 
