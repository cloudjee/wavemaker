PageAbout.widgets = {
	layoutBox1: ["wm.Layout", {"horizontalAlign":"center","verticalAlign":"top"}, {}, {
		htmlAbout: ["wm.Html", {"html":"resources/htmlcontent/About.txt","minDesktopHeight":15,"width":"80%"}, {}]
	}]
}