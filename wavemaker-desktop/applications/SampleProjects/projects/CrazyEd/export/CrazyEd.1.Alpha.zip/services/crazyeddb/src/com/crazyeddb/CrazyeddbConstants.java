
package com.crazyeddb;



/**
 *  Query names for service "crazyeddb"
 *  10/13/2012 19:18:45
 * 
 */
public class CrazyeddbConstants {

    public final static String getInventoryByIdQueryName = "getInventoryById";

}
