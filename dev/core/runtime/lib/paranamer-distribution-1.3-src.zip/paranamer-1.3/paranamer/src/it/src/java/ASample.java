
public class ASample {

    public void aSampleMethod(String param1, Long param2){
        //
    }
    
}
