/*
 * LicenseContentTest.java
 * JUnit based test
 *
 * Created on 15. Juni 2005, 22:28
 */
/*
 * Copyright 2005 Schlichtherle IT Services
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package de.schlichtherle.license;

import de.schlichtherle.xml.*;

import java.beans.*;
import java.io.*;
import java.lang.reflect.*;
import java.text.DateFormat;
import java.util.*;

import javax.security.auth.x500.X500Principal;

import junit.framework.*;

/**
 * @author Christian Schlichtherle
 */
public class LicenseContentTest extends TestCase implements Serializable {
    
    protected LicenseContent content;
    protected Listener listener;
    
    public LicenseContentTest(String testName) {
        super(testName);
    }

    protected void setUp() {
        listener = new Listener();
        content = new LicenseContent();
        content.addPropertyChangeListener(listener);
    }

    protected void tearDown() {
        content.removePropertyChangeListener(listener);
        listener = null;
        content = null;
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(LicenseContentTest.class);
        
        return suite;
    }

    private static final long MILLIS_PER_DAY = 24 * 60 * 60 * 1000;
    
    public void testMidnight() {
        System.out.println("testMidnight");
        final long offset = Calendar.getInstance().get(Calendar.ZONE_OFFSET)
                + Calendar.getInstance().get(Calendar.DST_OFFSET);
        Date midnight = new Date((System.currentTimeMillis() + offset)
                / MILLIS_PER_DAY * MILLIS_PER_DAY - offset);
        assertEquals(midnight.getTime(), LicenseManager.midnight().getTime());
    }
    
    public void testGetHolder() {
        System.out.println("testGetHolder");
        assertNull(content.getHolder());
    }
    
    /**
     * Test of setHolder method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testSetHolder() {
        System.out.println("testSetHolder");
        final X500Principal expected = new X500Principal("CN=Test");
        content.setHolder(expected);
        assertSame(expected, content.getHolder());
        assertEquals(1, listener.getCount());
    }

    public void testGetIssuer() {
        System.out.println("testGetIssuer");
        assertNull(content.getIssuer());
    }

    /**
     * Test of setIssuer method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testSetIssuer() {
        System.out.println("testSetIssuer");
        final X500Principal expected = new X500Principal("CN=Test");
        content.setIssuer(expected);
        assertSame(expected, content.getIssuer());
        assertEquals(1, listener.getCount());
    }

    public void testGetSubject() {
        System.out.println("testGetSubject");
        assertNull(content.getSubject());
    }

    /**
     * Test of setSubject method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testSetSubject() {
        System.out.println("testSetSubject");
        final String expected = "Test";
        content.setSubject(expected);
        assertSame(expected, content.getSubject());
        assertEquals(1, listener.getCount());
    }

    /**
     * Test of getIssued method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testGetIssued() {
        System.out.println("testGetIssued");
        assertNull(content.getIssued());
    }

    /**
     * Test of setIssued method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testSetIssued() {
        System.out.println("testSetIssued");
        final Date expected = LicenseManager.midnight(); // do not use new Date() - equal dates will not fire property change event!
        content.setIssued(expected);
        assertSame(expected, content.getIssued());
        assertEquals(1, listener.getCount());
    }

    /**
     * Test of getNotBefore method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testGetNotBefore() {
        System.out.println("testGetNotBefore");
        assertNull(content.getNotBefore());
    }

    /**
     * Test of setNotBefore method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testSetNotBefore() {
        System.out.println("testSetNotBefore");
        final Date expected = new Date();
        content.setNotBefore(expected);
        assertSame(expected, content.getNotBefore());
        assertEquals(1, listener.getCount());
    }

    /**
     * Test of getNotAfter method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testGetNotAfter() {
        System.out.println("testGetNotAfter");
        assertNull(content.getNotAfter());
    }

    /**
     * Test of setNotAfter method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testSetNotAfter() {
        System.out.println("testSetNotAfter");
        final Date expected = new Date();
        content.setNotAfter(expected);
        assertSame(expected, content.getNotAfter());
        assertEquals(1, listener.getCount());
    }

    /**
     * Test of getConsumerType method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testGetConsumerType() {
        System.out.println("testGetConsumerType");
        assertNull(content.getConsumerType());
    }

    /**
     * Test of setConsumerType method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testSetConsumerType() {
        System.out.println("testSetConsumerType");
        final String expected = "Test";
        content.setConsumerType(expected);
        assertSame(expected, content.getConsumerType());
        assertEquals(1, listener.getCount());
    }

    /**
     * Test of getConsumerAmount method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testGetConsumerAmount() {
        System.out.println("testGetConsumerAmount");
        assertEquals(1, content.getConsumerAmount());
    }

    /**
     * Test of setConsumerAmount method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testSetConsumerAmount() {
        System.out.println("testSetConsumerAmount");
        final int expected = 2;
        content.setConsumerAmount(expected);
        assertEquals(expected, content.getConsumerAmount());
        assertEquals(1, listener.getCount());
    }

    /**
     * Test of getInfo method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testGetInfo() {
        System.out.println("testGetInfo");
        assertNull(content.getInfo());
    }

    /**
     * Test of setInfo method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testSetInfo() {
        System.out.println("testSetInfo");
        final String expected = "Test";
        content.setInfo(expected);
        assertSame(expected, content.getInfo());
        assertEquals(1, listener.getCount());
    }

    /**
     * Test of getExtra method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testGetExtra() {
        System.out.println("testGetExtra");
        assertNull(content.getExtra());
    }

    /**
     * Test of setExtra method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testSetExtra() {
        System.out.println("testSetExtra");
        final String expected = "Test";
        content.setExtra(expected);
        assertSame(expected, content.getExtra());
        assertEquals(1, listener.getCount());
    }

    public void testEqualsAndHashCode() {
        System.out.println("testEqualsAndHashCode");
        content.setSubject("Test");
        content.setHolder(new X500Principal("CN=CaSeIsIgNoReD"));
        LicenseContent other = new LicenseContent();
        other.setSubject("Test");
        other.setHolder(new X500Principal("cn=cAsEiSiGnOrEd"));
        content.setIssued(new Date());
        other.setIssued((Date) content.getIssued().clone());
        assertEquals(content, content);
        assertEquals(other, other);
        assertEquals(content, other);
        assertEquals(content.hashCode(), other.hashCode());
    }
    
    /**
     * Test of removePropertyChangeListener method, of class de.schlichtherle.license.LicenseContent.
     */
    public void testRemovePropertyChangeListener() {
        System.out.println("testRemovePropertyChangeListener");
        content.removePropertyChangeListener(listener);
        content.setSubject("Hello world!");
        assertEquals(0, listener.getCount());
    }
    
    /**
     * Tests if the (de)serialization with ObjectInput/OutputStream works.
     */
    public synchronized void testObjectStreamPersistence()
    throws Exception {
        System.out.println("testObjectStreamPersistence");
        content.setNotBefore(new Date(LicenseManager.midnight().getTime() + 24 * 60 * 60 * 1000));
        content.setSubject("Test Subject");
        content.setHolder(new X500Principal("CN=Test"));
        final LicenseContent content2;
        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(content);
        oos.close();
        final ObjectInputStream ois = new ObjectInputStream(
                new ByteArrayInputStream(bos.toByteArray()));
        content2 = (LicenseContent) ois.readObject();
        ois.close();
        testPersistence(content, content2);
    }
    
    /**
     * Tests if the (de)serialization with ObjectInput/OutputStream works.
     */
    public synchronized void testXMLPersistence()
    throws Exception {
        System.out.println("testXMLPersistence");
        content.setNotBefore(new Date(LicenseManager.midnight().getTime() + 24 * 60 * 60 * 1000));
        content.setSubject("Test Subject");
        content.setHolder(new X500Principal("CN=Test"));
        final LicenseContent content2;
        final byte[] buf = PersistenceService.store2ByteArray(content);
        content2 = (LicenseContent) PersistenceService.load(buf);
        testPersistence(content, content2);
    }

    protected synchronized void testPersistence(LicenseContent original, LicenseContent clone) {
        // Check properties first
        assertEqualsButNotSame(original, clone);

        // Check that the original's event listeners have not been persisted.
        listener.resetStaticCount();

        original.setSubject("Test 1"); // SHOULD fire
        assertEquals(1, listener.getStaticCount());

        clone.setSubject("Test 2"); // should NOT fire
        assertEquals(1, listener.getStaticCount());
        
        clone.addPropertyChangeListener(listener);
        clone.setSubject("Test 3"); // SHOULD fire now
        assertEquals(2, listener.getStaticCount());
    }

    protected void assertEqualsButNotSame(LicenseContent expected, LicenseContent actual) {
        assertNotNull(expected);
        assertNotNull(actual);
        assertNotSame(expected, actual);
        super.assertEquals(expected, actual);
        assertEquals(expected.getConsumerAmount(), actual.getConsumerAmount());
        assertNullOrNotSame(expected.getConsumerType(), actual.getConsumerType());
        assertNullOrNotSame(expected.getHolder(), actual.getHolder());
        assertNullOrNotSame(expected.getInfo(), actual.getInfo());
        assertNullOrNotSame(expected.getIssued(), actual.getIssued());
        assertNullOrNotSame(expected.getIssuer(), actual.getIssuer());
        assertNullOrNotSame(expected.getNotAfter(), actual.getNotAfter());
        assertNullOrNotSame(expected.getNotBefore(), actual.getNotBefore());
        assertNullOrNotSame(expected.getSubject(), actual.getSubject());
    }
    
    protected final void assertNullOrNotSame(Object expected, Object actual) {
        if (expected != null || actual != null)
            assertNotSame(expected, actual);
    }

    private static int staticCount;
    
    protected class Listener implements PropertyChangeListener, Serializable {
        private int count;
        
        public int getCount() {
            return count;
        }

        public int getStaticCount() {
            return staticCount;
        }
        
        public void resetStaticCount() {
            staticCount = 0;
        }
        
        public synchronized void propertyChange(PropertyChangeEvent evt) {
            assertNotNull(evt);
            assertTrue(evt.getSource() instanceof LicenseContent);
            count++;
            staticCount++;
        }
    }
}
